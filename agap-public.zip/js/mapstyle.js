function setMyMapStyle(){
  var mps = [
        {featureType: "landscape",
        stylers: [{visibility: "off"}]}, 
        
        {featureType: "transit",
        stylers: [{visibility: "off"}]}, 

        {featureType: "poi.park", elementType: "labels",
        stylers: [{visibility: "off"}]}, 

        {featureType: "poi.park", elementType: "geometry.fill",
        stylers: [{color: "#d3d3d3"}, {visibility: "on"}]}, 

        {featureType: "road", elementType: "geometry.stroke",
        stylers: [{visibility: "off"}]}, 

        {featureType: "landscape", 
        stylers: [{visibility: "on"}, {hue: "#0008ff"}, {lightness: -75}, {saturation: 10}]}, 
        {elementType: "geometry.stroke",
        stylers: [{color: "#1f1d45"}]}, 
        
        {featureType: "landscape.natural",
        stylers: [{color: "#0d1072"}]}, 
        
        {featureType: "water", elementType: "geometry.fill",
        stylers: [{visibility: "on"}, {color: "#707dfa"}]}, 
        {elementType: "labels.text.fill",
        stylers: [{visibility: "on"}, {color: "#e7e8ec"}]}, 
        {elementType: "labels.text.stroke",
        stylers: [{visibility: "on"}, {color: "#151348"}]}, 

        {featureType: "administrative", elementType: "labels.text.fill",
        stylers: [{visibility: "on"}, {color: "#f7fdd9"}]}, 

        {featureType: "administrative", elementType: "labels.text.stroke",
        stylers: [{visibility: "on"}, {color: "#01001f"}]}, 

        {featureType: "road", elementType: "geometry.fill",
        stylers: [{visibility: "on"}, {color: "#316694"}]}, 

        {featureType: "road", elementType: "labels.icon",
        stylers: [{visibility: "off"}]}, 

        {featureType: "water", elementType: "labels",
        stylers: [{visibility: "off"}]}, 
        
        {featureType: "poi", elementType: "geometry.fill",
        stylers: [{color: "#707dfa"}]}
    ];
    return mps;
}